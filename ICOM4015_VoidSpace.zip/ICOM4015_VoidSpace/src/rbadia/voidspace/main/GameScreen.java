package rbadia.voidspace.main;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JPanel;

import rbadia.voidspace.graphics.GraphicsManager;
import rbadia.voidspace.model.Asteroid;
import rbadia.voidspace.model.Bullet;
import rbadia.voidspace.model.EnemyBullet;
import rbadia.voidspace.model.EnemyShip;
import rbadia.voidspace.model.Inmortal;
import rbadia.voidspace.model.Ship;
import rbadia.voidspace.sounds.SoundManager;


/**
 * Main game screen. Handles all game graphics updates and some of the game
 * logic.
 */
public class GameScreen extends JPanel {
  private static final long serialVersionUID = 1L;

  private BufferedImage backBuffer;
  private Graphics2D g2d;

  private long lastShipTime;

  private Rectangle asteroidExplosion;
  private Rectangle shipExplosion;
  private Rectangle enemyShipExplosion;
  private JLabel shipsValueLabel;
  private JLabel destroyedValueLabel;
  private JLabel destroyedEnemyShipsValueLabel;
  private JLabel levelValueLabel;
  private JLabel pointsValueLabel;


  private Random rand;

  private Font originalFont;
  private Font bigFont;
  private Font biggestFont;

  private GameStatus status;
  private SoundManager soundMan;
  private GraphicsManager graphicsMan;
  private GameLogic gameLogic;
  

  /**
   * This method initializes
   * 
   */
  public GameScreen() {
    super();
    // initialize random number generator
    rand = new Random();

    initialize();

    // initialize graphics manager
    graphicsMan = new GraphicsManager();

    // initialize back buffer image
    backBuffer = new BufferedImage(Rules.GAMEX_FRAME, Rules.GAMEY_FRAME,
        BufferedImage.TYPE_INT_RGB);
    g2d = backBuffer.createGraphics();
  }

  /**
   * Initialization method (for VE compatibility).
   */
  private void initialize() {
    // set panel properties
    this.setSize(new Dimension(Rules.GAMEX_FRAME, Rules.GAMEY_FRAME));
    this.setPreferredSize(new Dimension(Rules.GAMEX_FRAME,
        Rules.GAMEY_FRAME));
    this.setBackground(Color.BLACK);
  }

  /**
   * Update the game screen.
   */
  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    // draw current backBuffer to the actual game screen
    g.drawImage(backBuffer, 0, 0, this);
  }

  /**
   * Update the game screen's backBuffer image.
   */
  public void updateScreen() {
    Ship ship = gameLogic.getShip();
    ArrayList<Asteroid> asteroids = gameLogic.getAsteroidList();
    ArrayList<Inmortal> inmortal = gameLogic.getinmortalList();
    ArrayList<EnemyShip> enemyShips = gameLogic.getEnemyShipList();
    List<Bullet> bullets = gameLogic.getBullets();
    List<EnemyBullet> enemyBullets = gameLogic.getEnemyBullets();

    // Setting the game Logic for Asteroids
    status.gameLogicSet(gameLogic);

    // set original font
    if (this.originalFont == null) {
      this.originalFont = g2d.getFont();
      this.bigFont = originalFont;
    }

    // erase screen
    g2d.setPaint(Color.BLACK);
    g2d.fillRect(0, 0, getSize().width, getSize().height);

    // draw 50 random stars
    drawStars(50);

    // if the game is starting, draw "Get Ready" message
    if (status.isGameStarting()) {
      drawGetReady();
      return;
    }

    // if the game is over, draw the "Game Over" message
    if (status.isGameOver()) {
      // draw the message
     
      drawGameOver();
      

      long currentTime = System.currentTimeMillis();

      // draw the explosions until their time passes(ASTEROIDS)
      for (int i = 0; i < asteroids.size(); i++) {
        Asteroid asteroid = asteroids.get(i);
        if ((currentTime - asteroid.getFinalAsteroidTime()) < Rules.ASTEROID_DELAY) {
          graphicsMan.drawAsteroidExplosion(asteroidExplosion, g2d, this);
        }
      }

      // draw the explosions until their time passes(ENEMY SHIPS)
      for (int i = 0; i < enemyShips.size(); i++) {
        EnemyShip enemyShip = enemyShips.get(i);
        if ((currentTime - enemyShip.getFinalEnemyShipTime()) < Rules.ENEMY_SHIP_DELAY) {
          graphicsMan.drawEnemyShipExplosion(enemyShipExplosion, g2d, this);
        }
      }

      if ((currentTime - lastShipTime) < Rules.SHIP_DELAY) {
        graphicsMan.drawShipExplosion(shipExplosion, g2d, this);
      }
      
      return;
      
      
    }

    // the game has not started yet
    if (!status.isGameStarted()) {
      // draw game title screen
      initialMessage();
      return;
    }

    // draw Asteroids
    drawAsteroids(asteroids);
    
    // drawEnemyShip
    drawEnemyShip(enemyShips);

    // draw Inmortal
    drawInmortal(inmortal);

    // draw bullets
    drawBullets(bullets);

    // draw enemyBullets
    drawEnemyBullets(enemyBullets);

    // draw ship
    drawShip(ship);

    // check bullet-asteroid collision
    bulletAndAsteroidCollision(asteroids, bullets);

    bulletAndInmortalCollisions(inmortal, bullets, enemyBullets);

    // check bullet-enemyShip collision
    bulletAndEnemyShipCollisions(enemyShips, bullets);

    // check enemyBullet-ship collision
    shipAndEnemyBulletCollisions(ship, enemyBullets);

    // check asteroid-ship collision
    asteroidsAndShipCollision(asteroids, ship);

    // check Inmortal - ship collision
    inmortalShipCollisions(inmortal, ship);

    // check ship-enemyShip collision
    shipEnemyShipCollision(ship, enemyShips);

    // check bullet collisions
    bulletAndEnemyBulletCollisions(bullets, enemyBullets);

    // update asteroids destroyed label
    destroyedValueLabel.setText(Long.toString(status.getAsteroidsDestroyed()));

    // update enemyShip destroyed label
    destroyedEnemyShipsValueLabel.setText(Long.toString(status.getEnemyShipsDestroyed()));

    // update ships left label
    shipsValueLabel.setText(Integer.toString(status.getShipsLeft()));

    // update level label
    levelValueLabel.setText(Integer.toString(status.getLevel()));

    // update points label

    pointsValueLabel.setText(Long.toString(status.getPoints()));



  }

  /**
   * Draw asteroids in the Screen
   * 
   * @param asteroids
   *          
   */
  private void drawAsteroids(ArrayList<Asteroid> asteroids) {
    // draw asteroid
    for (int i = 0; i < asteroids.size(); i++) {
      Asteroid asteroid = asteroids.get(i);
      if (!asteroid.newStatus()) {
        // To draw an asteroid until it reach the bottom part

        int horizontalMovement;
        int verticalMovement;
        if (asteroid.getY() + asteroid.getSpeed() < this.getHeight()) {

          //  Horizontal movement
          if (status.getLevel() < Rules.LEVEL_UP_ASTEROIDS) {
            horizontalMovement = 0;
          } else if (Rules.ASTEROID_TRASLATION) {
            long currentTime = System.currentTimeMillis();
            double x = Math.cos(currentTime / 1000.0 + asteroid.getRandomMove());
            horizontalMovement = (int) (3 * x + 2 * x * x * x); 
          }
          
          else if (asteroid.getHorizontalLocation() < (this.getWidth() / 2)) {
            if (Rules.ASTEROID_MOVEMENT)
              horizontalMovement = asteroid.getHorizontalSpeed()
                  * (rand.nextInt(asteroid.getDefaultSpeed()) - 1) + 1;
            else
              horizontalMovement = asteroid.getHorizontalSpeed();
          } else {
            if (Rules.ASTEROID_MOVEMENT)
              horizontalMovement = -asteroid.getHorizontalSpeed()
                  * (rand.nextInt(asteroid.getDefaultSpeed()) - 1) + 1;
            else
              horizontalMovement = -asteroid.getHorizontalSpeed();
          }

          // Change Vertical Movement
          if (status.getLevel() < Rules.LEVEL_UP_ASTEROIDS2) {
            verticalMovement = asteroid.getSpeed();
          } else if (status.getLevel() < Rules.LEVEL_UP_ASTEROIDS3) {
            verticalMovement = (int) (asteroid.getSpeed() * Rules.ACCELERATE_ASTEROIDS2);
          } else {
            verticalMovement = (int) (asteroid.getSpeed() * Rules.ACCELERATE_ASTEROIDS3 );
          }

         
          asteroid.translate(horizontalMovement, verticalMovement);
          graphicsMan.drawAsteroid(asteroid, g2d, this);
        } else {
          asteroid.setLocation(rand.nextInt(getWidth() - asteroid.width), 0);
          asteroid.setHorizontalSpeed(rand.nextInt(asteroid.getSpeed()));

        }
      } else {
        long currentTime = System.currentTimeMillis();
        // Check the last Asteroid Time 
        if ((currentTime - asteroid.getFinalAsteroidTime()) > Rules.ASTEROID_DELAY) {
          // draw a new asteroid
          asteroid.setFinalAsteroidTime(currentTime);
          asteroid.newStatus(false);
          asteroid.setLocation(rand.nextInt(getWidth() - asteroid.width), 0);
        } else {
          // draw explosion (keep drawing this explosion...)
          graphicsMan.drawAsteroidExplosion(asteroidExplosion, g2d, this);
        }
      }
    }

  }

  

  /**
   * Draw enemy Ship 
   * @param enemyShips
   *          
   */
  private void drawEnemyShip(ArrayList<EnemyShip> enemyShips) {
    // draw enemyShip
    for (int i = 0; i < enemyShips.size(); i++) {
      EnemyShip enemyShip = enemyShips.get(i);
      if (!enemyShip.newStatus()) {
        // draw the enemyShip until it reaches the bottom of the screen

        int horizontalMovement;
        int verticalMovement;
        if (enemyShip.getY() + enemyShip.getSpeed() < this.getHeight()) {

          long currentTime = System.currentTimeMillis();
          double x = Math.cos(currentTime / 1000.0 + enemyShip.getRandomMove());

          if (status.getLevel() < Rules.LEVEL_TO_MOVE_ENEMY_SHIP_2X) {
            verticalMovement = enemyShip.getSpeed();
            horizontalMovement = (int) (3 * x + 2 * x * x * x);
          } else if (status.getLevel() < Rules.LEVEL_TO_MOVE_ENEMY_SHIP_3X) {
            verticalMovement = (int) (enemyShip.getSpeed() * Rules.ACCELERATE_ENEMYSHIP2);
            horizontalMovement = (int) (3 * x + 2 * x * x * x);
          } else {
            verticalMovement = (int) (enemyShip.getSpeed() * Rules.ACCELERATE_ENEMYSHIP3);
            horizontalMovement = (int) (5 * x + 2 * x * x * x);
          }

          enemyShip.translate(horizontalMovement, verticalMovement);
          graphicsMan.drawEnemyShip(enemyShip, g2d, this);

          // fire enemy bullets
          if ((currentTime - enemyShip.getEnemyBulletTime()) > enemyShip.getStopTime()) {
            enemyShip.setEnemyBulletTime(currentTime);
            gameLogic.fireEnemyBullet(i);
            enemyShip.changeStoptime();
          }

        } else {
          enemyShip.setLocation(rand.nextInt(getWidth() - enemyShip.width), 0);
          enemyShip.setHorizontalSpeed(rand.nextInt(enemyShip.getSpeed()));

        }
      } else {
        long currentTime = System.currentTimeMillis();
        if ((currentTime - enemyShip.getFinalEnemyShipTime()) > Rules.ENEMY_SHIP_DELAY) {
          // To draw the enemy ship and the bullets 
          enemyShip.setFinalEnemyShipTime(currentTime);
          enemyShip.newStatus(false);
          enemyShip.setLocation(rand.nextInt(getWidth() - enemyShip.width), 0);
          gameLogic.fireEnemyBullet(i);
        } else {
          // To draw the explosion
          graphicsMan.drawEnemyShipExplosion(enemyShipExplosion, g2d, this);
        }
      }
    }
  }
  
  /**
   * Draw the Inmortal on the Screen
   * 
   * @param inmortals
   *         
   */
  private void drawInmortal(ArrayList<Inmortal> inmortal) {
    // draw Inmortal
	 
    for (int i = 0; i < inmortal.size(); i++) {
      Inmortal inmortals = inmortal.get(i);
      if (!inmortals.newStatus()) {
        // draw the Inmortal until it reach the bottom part

        int horizontalMovement;
        int verticalMovement;
        if (inmortals.getY() + inmortals.getSpeed() < this.getHeight()) {

          // change Horizontal Movement
          if (status.getLevel() < Rules.LEVEL_UP_ASTEROIDS) {
            horizontalMovement = 0;
          } else if (Rules.ASTEROID_TRASLATION) {
            long currentTime = System.currentTimeMillis();
            double x = Math.cos(currentTime / 1000.0 + inmortals.getRandomMove());
            horizontalMovement = (int) (3 * x + 2 * x * x * x);
          }
        
          else if (inmortals.getHorizontalLocation() < (this.getWidth() / 2)) {
            if (Rules.ASTEROID_MOVEMENT)
              horizontalMovement = inmortals.getHorizontalSpeed()
                  * (rand.nextInt(inmortals.getDefaultSpeed()) - 1) + 1;
            else
              horizontalMovement = inmortals.getHorizontalSpeed();
          } else {
            if (Rules.ASTEROID_MOVEMENT)
              horizontalMovement = -inmortals.getHorizontalSpeed()
                  * (rand.nextInt(inmortals.getDefaultSpeed()) - 1) + 1;
            else
              horizontalMovement = -inmortals.getHorizontalSpeed();
          }

          // Change speed for  Vertical Movement 
          if (status.getLevel() < Rules.LEVEL_UP_ASTEROIDS2) {
            verticalMovement = inmortals.getSpeed();
          } else if (status.getLevel() < Rules.LEVEL_UP_ASTEROIDS3) {
            verticalMovement = (int) (inmortals.getSpeed() * Rules.ACCELERATE_ASTEROIDS2);
          } else {
            verticalMovement = (int) (inmortals.getSpeed() * Rules.ACCELERATE_ASTEROIDS3 );
          }

        
          inmortals.translate(horizontalMovement, verticalMovement);
          graphicsMan.drawInmortal(inmortals, g2d, this);
        } else {
          inmortals.setLocation(rand.nextInt(getWidth() - inmortals.width), 0);
          inmortals.setHorizontalSpeed(rand.nextInt(inmortals.getSpeed()));

        }
      } else {
        long currentTime = System.currentTimeMillis();
        // Check asteroid time 
        if ((currentTime - inmortals.getFinalAsteroidTime()) > Rules.ASTEROID_DELAY) {
          // Draw a new inmortal
          inmortals.setFinalAsteroidTime(currentTime);
          inmortals.newStatus(false);
          inmortals.setLocation(rand.nextInt(getWidth() - inmortals.width), 0);
        } else {
          // draw explosion (keep drawing this explosion...)
          graphicsMan.drawAsteroidExplosion(asteroidExplosion, g2d, this);
        }
      }
      
    }
  
  }
  
  /**
   * Draws the player's ship to the screen
   * 
   * @param ship
   *         
   */
  private void drawShip(Ship ship) {
    // draw ship
    if (!status.isNewShip()) {
      // draw it in its current location
      graphicsMan.drawShip(ship, g2d, this);
    } else {
      // draw a new one
      long currentTime = System.currentTimeMillis();
      if ((currentTime - lastShipTime) > Rules.SHIP_DELAY) {
        lastShipTime = currentTime;
        status.setNewShip(false);
        ship = gameLogic.newShip(this);
      } else {
        // draw explosion
        graphicsMan.drawShipExplosion(shipExplosion, g2d, this);
      }
    }
  }

  /**
   * To draw the player's ship bullets
   * 
   * @param bullets
   *       
   */
  private void drawBullets(List<Bullet> bullets) {
    for (int i = 0; i < bullets.size(); i++) {
      Bullet bullet = bullets.get(i);
      graphicsMan.drawBullet(bullet, g2d, this);

      boolean remove = gameLogic.moveBullet(bullet);
      if (remove) {
        bullets.remove(i);
        i--;
      }
    }
  }
  
 

  /**
   * To draw the enemy ship Bullets
   * 
   * @param enemyBullets
   *          
   */
  private void drawEnemyBullets(List<EnemyBullet> enemyBullets) {
    for (int i = 0; i < enemyBullets.size(); i++) {
      EnemyBullet enemyBullet = enemyBullets.get(i);
      graphicsMan.drawEnemyBullet(enemyBullet, g2d, this);

      boolean remove = gameLogic.moveEnemyBullet(enemyBullet);
      if (remove) {
        enemyBullets.remove(i);
        i--;
      }
    }
  }



  /**
   * Collisions between the enemy ships and the player's bullets
   * 
   * @param enemyShips in the Screen
   *          
   * @param bullets of the player
   *          
   */
  private void bulletAndEnemyShipCollisions(ArrayList<EnemyShip> enemyShips, List<Bullet> bullets) {
    for (int j = 0; j < enemyShips.size(); j++) {
      EnemyShip enemyShip = enemyShips.get(j);
      for (int i = 0; i < bullets.size(); i++) {
        Bullet bullet = bullets.get(i);
        if (enemyShip.intersects(bullet)) {
          // increase asteroids destroyed count
          status.setEnemyShipsDestroyed(status.getEnemyShipsDestroyed() + 1);

          // remove the enemyShip
          enemyShipExplosion = new Rectangle(enemyShip.x, enemyShip.y, enemyShip.width,
              enemyShip.height);
          enemyShip.setLocation(-enemyShip.width, -enemyShip.height);
          enemyShip.newStatus(true);
          enemyShip.setFinalEnemyShipTime(System.currentTimeMillis());

          // play asteroid explosion sound
          soundMan.playEnemyShipExplosionSound();

          // remove bullet
          bullets.remove(i);
          break;
        }
      }
    }
  }

  /**
   * Collisions between Inmortal and bullets
   * 
   * @param inmortals in the screen
   *          
   * @param bullets of the player
   *          
   */
  private void bulletAndInmortalCollisions(ArrayList<Inmortal> inmortals,
      List<Bullet> bullets, List<EnemyBullet> enemyBullets) {
    for (int j = 0; j < inmortals.size(); j++) {
      Inmortal inmortal = inmortals.get(j);
      for (int i = 0; i < bullets.size(); i++) {
        Bullet bullet = bullets.get(i);
        if (inmortal.intersects(bullet)) {
          // remove bullet and add an enemyBullet
          bullets.remove(i);
          enemyBullets.add(new EnemyBullet(inmortal));

          // sound
          soundMan.playInmortal();
          break;
        }
      }
    }
  }

  /**
   *Collisions between the player bullets and the enemy bullets
   * 
   * @param bullets of the player
   *         
   * @param enemyBullets
   *          
   */
  private void bulletAndEnemyBulletCollisions(List<Bullet> bullets, List<EnemyBullet> enemyBullets) {
    for (int j = 0; j < enemyBullets.size(); j++) {
      EnemyBullet enemyBullet = enemyBullets.get(j);
      for (int i = 0; i < bullets.size(); i++) {
        Bullet bullet = bullets.get(i);
        if (enemyBullet.intersects(bullet)) {
          // remove bullet
          bullets.remove(i);
          enemyBullets.remove(j);
       // sound
          soundMan.playEnemyShipExplosionSound();
          break;
        }
      }
    }
  }

  /**
   * Collisions between the player ship and the enemy bullets
   * @param ship         
   * @param enemyBullets
   *          
   */
  private void shipAndEnemyBulletCollisions(Ship ship, List<EnemyBullet> enemyBullets) {
    // Verify the collision of the enemy ship bullets
    for (int i = 0; i < enemyBullets.size(); i++) {
      EnemyBullet enemyBullet = enemyBullets.get(i);
      if (ship.intersects(enemyBullet)) {
        // decrease the number of the ships
        status.setShipsLeft(status.getShipsLeft() - 1);

        // Remove a ship
        shipExplosion = new Rectangle(ship.x, ship.y, ship.width, ship.height);
        ship.setLocation(this.getWidth() + ship.width, -ship.height);
        status.setNewShip(true);
        lastShipTime = System.currentTimeMillis();

        // play ship explosion sound
        soundMan.playShipExplosionSound();

        // remove bullet
        enemyBullets.remove(i);
        break;
      }
    }
  }
  /**
   * Collisions between the asteroids and the player ship
   * 
   * @param asteroids
   *          
   * @param ship
   *         
   */
  private void asteroidsAndShipCollision(ArrayList<Asteroid> asteroids, Ship ship) {
    // Verify ship and asteroids collisions
    for (int i = 0; i < asteroids.size(); i++) {
      Asteroid asteroid = asteroids.get(i);
      if (asteroid.intersects(ship)) {
        // Decrease numbers of ships left
        status.setShipsLeft(status.getShipsLeft() - 1);

        status.setAsteroidsDestroyed(status.getAsteroidsDestroyed() + 1);

        // Remove the asteroid
        asteroidExplosion = new Rectangle(asteroid.x, asteroid.y, asteroid.width, asteroid.height);
        asteroid.setLocation(-asteroid.width, -asteroid.height);
        asteroid.newStatus(true);
        asteroid.setFinalAsteroidTime(System.currentTimeMillis());

        // Remove the Ship
        shipExplosion = new Rectangle(ship.x, ship.y, ship.width, ship.height);
        ship.setLocation(this.getWidth() + ship.width, -ship.height);
        status.setNewShip(true);
        lastShipTime = System.currentTimeMillis();

        // play ship explosion sound
        soundMan.playShipExplosionSound();
        // play asteroid explosion sound
        soundMan.playAsteroidExplosionSound();
      }
    }
  }

  /**
   * Collisions between the player ship and the enemy ships
   * 
   * @param ship
   *          - the player's ship on the screen
   * @param enemyShips
   *          - the list of enemy ships on the screen
   */
  private void shipEnemyShipCollision(Ship ship, ArrayList<EnemyShip> enemyShips) {
    // Verify the collisions of the Enemy Ship
    for (int i = 0; i < enemyShips.size(); i++) {
      EnemyShip enemyShip = enemyShips.get(i);
      if (enemyShip.intersects(ship)) {
        // decrease number of ships left
        status.setShipsLeft(status.getShipsLeft() - 1);

        status.setEnemyShipsDestroyed(status.getEnemyShipsDestroyed() + 1);

        // Remove the enemyShip
        enemyShipExplosion = new Rectangle(enemyShip.x, enemyShip.y, enemyShip.width,
            enemyShip.height);
        enemyShip.setLocation(-enemyShip.width, -enemyShip.height);
        enemyShip.newStatus(true);
        enemyShip.setFinalEnemyShipTime(System.currentTimeMillis());

        // Remove the player's ship
        shipExplosion = new Rectangle(ship.x, ship.y, ship.width, ship.height);
        ship.setLocation(this.getWidth() + ship.width, -ship.height);
        status.setNewShip(true);
        lastShipTime = System.currentTimeMillis();

        // play ship explosion sound
        soundMan.playShipExplosionSound();
        // play asteroid explosion sound
        soundMan.playEnemyShipExplosionSound();
      }
    }
  }

  /**
   * Collisions between the player bullets and the asteroids
   * 
   * @param asteroids
   *         
   * @param bullets
   *         
   */
  private void bulletAndAsteroidCollision(ArrayList<Asteroid> asteroids, List<Bullet> bullets) {
    //Verify the  bullet and the asteroid collisions for all the asteroids
    for (int j = 0; j < asteroids.size(); j++) {
      Asteroid asteroid = asteroids.get(j);
      for (int i = 0; i < bullets.size(); i++) {
        Bullet bullet = bullets.get(i);
        if (asteroid.intersects(bullet)) {
          // Counter for asteroids destroyed 
          status.setAsteroidsDestroyed(status.getAsteroidsDestroyed() + 1);

          // Remove an asteroid
          asteroidExplosion = new Rectangle(asteroid.x, asteroid.y, asteroid.width, asteroid.height);
          asteroid.setLocation(-asteroid.width, -asteroid.height);
          asteroid.newStatus(true);
          asteroid.setFinalAsteroidTime(System.currentTimeMillis());

          // play asteroid explosion sound
          soundMan.playAsteroidExplosionSound();

          // remove bullet
          bullets.remove(i);
          break;
        }
      }
    }
  }


  /**
   * Collisions between the Inmortal and the player's ship
   * 
   * @param inmortals
   *          
   * @param ship
   *         
   */
  private void inmortalShipCollisions(ArrayList<Inmortal> inmortals, Ship ship) {
    // check ship-asteroid collisions for each asteroid
    for (int i = 0; i < inmortals.size(); i++) {
      Inmortal inmortal = inmortals.get(i);
      if (inmortal.intersects(ship)) {
        // decrease number of ships left
        status.setShipsLeft(status.getShipsLeft() - 1);

        // "remove" ship
        shipExplosion = new Rectangle(ship.x, ship.y, ship.width, ship.height);
        ship.setLocation(this.getWidth() + ship.width, -ship.height);
        status.setNewShip(true);
        lastShipTime = System.currentTimeMillis();
        
        soundMan.playInmortal();
        break;
      }
    }
  }

  /**
   * Draws the "Game Over" message.
   */
  private void drawGameOver() {
	
    String gameOverStr = "GAME OVER"; 
    Font currentFont = biggestFont == null ? bigFont : biggestFont;
    float fontSize = currentFont.getSize2D();
    bigFont = currentFont.deriveFont(fontSize + 1).deriveFont(Font.BOLD);
    FontMetrics fm = g2d.getFontMetrics(bigFont);
    int strWidth = fm.stringWidth(gameOverStr);
    if (strWidth > this.getWidth() - 10) {
      biggestFont = currentFont;
      bigFont = biggestFont;
      fm = g2d.getFontMetrics(bigFont);
      strWidth = fm.stringWidth(gameOverStr);
    
    }
    int ascent = fm.getAscent();
    int strX = (this.getWidth() - strWidth) / 2;
    int strY = (this.getHeight() + ascent) / 2;
    g2d.setFont(bigFont);
    g2d.setPaint(Color.RED);
    g2d.drawString(gameOverStr, strX, strY);
    
  }

  /**
   * Draws the initial "Get Ready!" message.
   */
  private void drawGetReady() {
    String readyStr = "Get Ready!";
    g2d.setFont(originalFont.deriveFont(originalFont.getSize2D() + 1));
    FontMetrics fm = g2d.getFontMetrics();
    int ascent = fm.getAscent();
    int strWidth = fm.stringWidth(readyStr);
    int strX = (this.getWidth() - strWidth) / 2;
    int strY = (this.getHeight() + ascent) / 2;
    g2d.setPaint(Color.WHITE);
    g2d.drawString(readyStr, strX, strY);
  }

  /**
   * Draws the specified number of stars randomly on the game screen.
   * 
   * @param numberOfStars
   *          the number of stars to draw
   */
  private void drawStars(int numberOfStars) {
    g2d.setColor(Color.WHITE);
    for (int i = 0; i < numberOfStars; i++) {
      int x = (int) (Math.random() * this.getWidth());
      int y = (int) (Math.random() * this.getHeight());
      g2d.drawLine(x, y, x, y);
    }
  }

  /**
   * Display initial game title screen.
   */
  private void initialMessage() {
    String gameTitleStr = "Void Space";

    Font currentFont = biggestFont == null ? bigFont : biggestFont;
    float fontSize = currentFont.getSize2D();
    bigFont = currentFont.deriveFont(fontSize + 1).deriveFont(Font.BOLD).deriveFont(Font.ITALIC);
    FontMetrics fm = g2d.getFontMetrics(bigFont);
    int strWidth = fm.stringWidth(gameTitleStr);
    if (strWidth > this.getWidth() - 10) {
      bigFont = currentFont;
      biggestFont = currentFont;
      fm = g2d.getFontMetrics(currentFont);
      strWidth = fm.stringWidth(gameTitleStr);
    }
    g2d.setFont(bigFont);
    int ascent = fm.getAscent();
    int strX = (this.getWidth() - strWidth) / 2;
    int strY = (this.getHeight() + ascent) / 2 - ascent;
    g2d.setPaint(Color.YELLOW);
    g2d.drawString(gameTitleStr, strX, strY);

    g2d.setFont(originalFont);
    fm = g2d.getFontMetrics();
    String newGameStr = "Press <Space> to Start a New Game.";
    strWidth = fm.stringWidth(newGameStr);
    strX = (this.getWidth() - strWidth) / 2;
    strY = (this.getHeight() + fm.getAscent()) / 2 + ascent + 16;
    g2d.setPaint(Color.WHITE);
    g2d.drawString(newGameStr, strX, strY);

    fm = g2d.getFontMetrics();
    String exitGameStr = "Press <Esc> to Exit the Game.";
    strWidth = fm.stringWidth(exitGameStr);
    strX = (this.getWidth() - strWidth) / 2;
    strY = strY + 16;
    g2d.drawString(exitGameStr, strX, strY);

    

    fm = g2d.getFontMetrics();
    String names = "Paola N. Torres & Carlos A. Rodriguez";
    strWidth = fm.stringWidth(names);
    strX = (this.getWidth() - strWidth) / 2;
    strY = strY + 16;
    g2d.drawString(names, strX, strY);
  }

  /**
   * Prepare screen for game over.
   */
  public void doGameOver() {
    shipsValueLabel.setForeground(new Color(128, 0, 0));
  }

  /**
   * Prepare screen for a new game.
   */
  public void doNewGame() {
    // initializes all asteroid times is not necessary
    lastShipTime = -Rules.SHIP_DELAY;

    bigFont = originalFont;
    biggestFont = null;

    // set labels' text
    shipsValueLabel.setForeground(Color.WHITE);
    shipsValueLabel.setText(Integer.toString(status.getShipsLeft()));
    destroyedValueLabel.setText(Long.toString(status.getAsteroidsDestroyed()));
    pointsValueLabel.setText(Long.toString(status.getPoints()));
    levelValueLabel.setText(Integer.toString(status.getLevel()));
    destroyedEnemyShipsValueLabel.setText(Long.toString(status.getEnemyShipsDestroyed()));
 

  }

  /**
   * Sets the game graphics manager.
   * 
   * @param graphicsMan
   *          the graphics manager
   */
  public void setGraphicsMan(GraphicsManager graphicsMan) {
    this.graphicsMan = graphicsMan;
  }

  /**
   * Sets the game logic handler
   * 
   * @param gameLogic
   *          the game logic handler
   */
  public void setGameLogic(GameLogic gameLogic) {
    this.gameLogic = gameLogic;
    this.status = gameLogic.getStatus();
    this.soundMan = gameLogic.getSoundMan();
  }

  /**
   * Sets the label that displays the value for asteroids destroyed.
   * 
   * @param destroyedValueLabel
   *          the label to set
   */
  public void setDestroyedValueLabel(JLabel destroyedValueLabel) {
    this.destroyedValueLabel = destroyedValueLabel;
  }

  /**
   * Sets the label that displays the value of the enemy ships destroyed
   * 
   * @param destroyedEnemyShipsValueLabel
   *          - the label to set
   */
  public void setDestroyedEnemyShipsValueLabel(JLabel destroyedEnemyShipsValueLabel) {
    this.destroyedEnemyShipsValueLabel = destroyedEnemyShipsValueLabel;
  }

  /**
   * Sets the label that displays the value of the points the player has
   * 
   * @param pointsValueLabel
   *          - the label to be set
   */
  public void setPointsValueLabel(JLabel pointsValueLabel) {
    this.pointsValueLabel = pointsValueLabel;
  }

  /**
   * sets the label that displays the value of the level the player is in
   * 
   * @param levelValueLabel
   *          - the label to be set
   */
  public void setLevelValueLabel(JLabel levelValueLabel) {
    this.levelValueLabel = levelValueLabel;
  }

 


  /**
   * Sets the label that displays the value for ship (lives) left
   * 
   * @param shipsValueLabel
   *          the label to set
   */
  public void setShipsValueLabel(JLabel shipsValueLabel) {
    this.shipsValueLabel = shipsValueLabel;
}
}
