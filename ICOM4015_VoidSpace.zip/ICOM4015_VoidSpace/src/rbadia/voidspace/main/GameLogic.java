package rbadia.voidspace.main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Timer;

import rbadia.voidspace.model.Asteroid;
import rbadia.voidspace.model.Bullet;
import rbadia.voidspace.model.Inmortal;
import rbadia.voidspace.model.EnemyBullet;
import rbadia.voidspace.model.EnemyShip;
import rbadia.voidspace.model.Ship;
import rbadia.voidspace.sounds.SoundManager;

/**
 * Handles general game logic and status.
 */
public class GameLogic {
  private GameScreen gameScreen;
  private GameStatus status;
  private SoundManager soundMan;

  private Ship ship;
  private ArrayList<Asteroid> asteroids;
  private ArrayList<EnemyShip> enemyShips;
  private List<Bullet> bullets;
  private List<EnemyBullet> enemyBullets;
  private ArrayList<Inmortal> inmortals;
  

  /**
   * Create a new game logic handler
   * 
   * @param gameScreen
   *          the game screen
   */
  public GameLogic(GameScreen gameScreen) {
    this.gameScreen = gameScreen;

    // initialize game status information
    status = new GameStatus();
    // initialize the sound manager
    soundMan = new SoundManager();

    // initialize some variables
    bullets = new ArrayList<Bullet>();
    inmortals = new ArrayList<Inmortal>();
    enemyBullets = new ArrayList<EnemyBullet>();
    asteroids = new ArrayList<Asteroid>();
   
  }

  /**
   * Returns the game status
   * 
   * @return the game status
   */
  public GameStatus getStatus() {
    return status;
  }

  /**
   * Returns the sound manager
   * 
   * @return the sound manager
   */
  public SoundManager getSoundMan() {
    return soundMan;
  }

  /**
   * Returns the game screen
   * 
   * @return the game screen
   */
  public GameScreen getGameScreen() {
    return gameScreen;
  }

  /**
   * Prepare for a new game.
   */
  public void newGame() {
	
    status.setGameStarting(true);
    soundMan.playNewGame();

    // Variables to start the Game
    bullets = new ArrayList<Bullet>();
    asteroids = new ArrayList<Asteroid>();
    inmortals = new ArrayList<Inmortal>();
    enemyShips = new ArrayList<EnemyShip>();
    enemyBullets = new ArrayList<EnemyBullet>();
   
    // Status to start the Game
    status.setShipsLeft(Rules.STARTING_SHIPS);
    status.setGameOver(false);
    status.setAsteroidsDestroyed(0);
    status.setEnemyShipsDestroyed(0);
    status.setPoints(0);
    status.setLevel(1);
   
  
    // New Ship
    newShip(gameScreen);

    //Asteroids for Level 1
    for (int i = 0; i < Rules.ASTEROIDS1; i++)
      asteroids.add(newAsteroid(gameScreen));

    // Enemy Ships for Level 1 
    for (int i = 0; i < Rules.ENEMYSHIPS1; i++)
      enemyShips.add(newEnemyShip(gameScreen));

    //Inmortal for Level 1 
    for (int i = 0; i < Rules.NUM_INMORTALS; i++)
      inmortals.add(new Inmortal(gameScreen));

    // prepare game screen
    gameScreen.doNewGame();

    // delay to display "Get Ready" message for GET_READY_DELAY_TIME
    // milliseconds
    Timer timer = new Timer(Rules.GET_READY_DELAY_TIME, new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        status.setGameStarting(false);
        status.setGameStarted(true);
      }
    });
    timer.setRepeats(false);
    timer.start();
  }

  /**
   * Check game or level ending conditions.
   */
  public void checkConditions() {
    // check game over conditions
    if (!status.isGameOver() && status.isGameStarted()) {
      if (status.getShipsLeft() == 0) {
        gameOver();
      }
    }
  }

  /**
   * Actions to take when the game is over.
   * Add PlayGameOver Sound
   */
  public void gameOver() {
	soundMan.playGameOver();
    status.setGameStarted(false);
    status.setGameOver(true);
    gameScreen.doGameOver();

    // delay to display "Game Over" message for GAME_OVER_DELAY_TIME
    // milliseconds
    Timer timer = new Timer(Rules.GAME_OVER_DELAY_TIME, new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        status.setGameOver(false);
      }
    });
    timer.setRepeats(false);
    timer.start();
  }

  /**
   * Fire a bullet from ship.
   */
  public void fireBullet() {
      Bullet bullet = new Bullet(ship);
      bullets.add(bullet);
      soundMan.playBulletSound();  
  }
  /**
   * Move a bullet once fired.
   * 
   * @param bullet the bullet to move
   *          
   * @return if the bullet should be removed from screen
   */
  public boolean moveBullet(Bullet bullet) {
    if (bullet.getY() - bullet.getSpeed() >= 0) {
      bullet.translate(0, -bullet.getSpeed());
      return false;
    } else {
      return true;
    }
  }
  
  /**
   * Fire enemy bullets from enemy ships
   */
  public void fireEnemyBullet(int i) {
    EnemyBullet enemyBullet = new EnemyBullet(enemyShips.get(i));
    enemyBullets.add(enemyBullet);
    soundMan.playEnemyBulletSound();
  }

  /**
   * Move the enemy bullet once fired
   * 
   * @param enemyBullet will be the bullet to move 
   *         
   * @return boolean - if the bullet need to be removed from the screen
   */
  public boolean moveEnemyBullet(EnemyBullet enemyBullet) {
    if (enemyBullet.getY() - enemyBullet.getSpeed() >= 0) {
      enemyBullet.translate(0, -enemyBullet.getSpeed());
      return false;
    } else {
      return true;
    }
  }

  /**
   * Create a new ship (and replace current one).
   */
  public Ship newShip(GameScreen screen) {
    this.ship = new Ship(screen);
    return ship;
  }

  /**
   * Create a new asteroid
   */
  public Asteroid newAsteroid(GameScreen screen) {
    return new Asteroid(screen);
  }
  
  /**
   * Create the enemy ship
   * 
   * @param screen - where to create it 
   *       
   * @return  enemy ship
   */
  public EnemyShip newEnemyShip(GameScreen screen) {
    return new EnemyShip(screen);
  }

  /**
   * Create the Inmortal
   * 
   * @param screen- where to create it
   *          
   * @return  inmortal
   */
  public Inmortal newinmortal(GameScreen screen) {
    return new Inmortal(screen);
  }

  

  /**
   * Returns the ship.
   * 
   * @return the ship
   */
  public Ship getShip() {
    return ship;
  }

  /**
   * It will return the asteroid List
   */
  public ArrayList<Asteroid> getAsteroidList() {
    return this.asteroids;
  }
  
  /**
  *It will return the Enemy Ship List
   */
  public ArrayList<EnemyShip> getEnemyShipList() {
    return this.enemyShips;
  }

  /**
  *It will return the Inmortal List
   */
  public ArrayList<Inmortal> getinmortalList() {
    return this.inmortals;
  }

 

  /**
   *Return the list of Bullets
   */
  public List<Bullet> getBullets() {
    return bullets;
  }

  /**
	 * Returns the list of bullets.
	 * @return the list of bullets
	 */
  public List<EnemyBullet> getEnemyBullets() {
    return enemyBullets;
  }
}
