package rbadia.voidspace.main;

import java.util.ArrayList;

import rbadia.voidspace.model.Asteroid;
import rbadia.voidspace.model.EnemyShip;

/**
 * Container for game flags and/or status variables.
 */
public class GameStatus {
	
  // game flags
  private boolean gameStarted = false;
  private boolean gameStarting = false;
  private boolean gameOver = false;

  // status variables
  private boolean newShip;
  private int shipsLeft;
  private long asteroidsDestroyed = 0;
  private long enemyShipsDestroyed = 0;
  private long points = 0;
  private int level = 1;

  // the game logic
  private GameLogic gameLogic;

  public GameStatus() {

  }

  /**
   * Indicates if the game has already started or not.
   * 
   * @return if the game has already started or not
   */
  public synchronized boolean isGameStarted() {
    return gameStarted;
  }

  /**
   * Sets the status of the game.
   * 
   * @param gameStarted
   *          - should be true if the game started, false otherwise
   */
  public synchronized void setGameStarted(boolean gameStarted) {
    this.gameStarted = gameStarted;
  }

  /**
   * Indicates if the game is starting ("Get Ready" message is displaying) or
   * not.
   * 
   * @return if the game is starting or not.
   */
  public synchronized boolean isGameStarting() {
    return gameStarting;
  }

  /**
   * Sets the status of the game (if its starting).
   * 
   * @param gameStarting
   *          - should be true if the game is starting, false otherwise
   */
  public synchronized void setGameStarting(boolean gameStarting) {
    this.gameStarting = gameStarting;
  }

  /**
   * Indicates if the game has ended and the "Game Over" message is displaying.
   * 
   * @return if the game has ended and the "Game Over" message is displaying.
   */
  public synchronized boolean isGameOver() {
    return gameOver;
  }

  /**
   * Sets the status of the game, if the game is over.
   * 
   * @param gameOver
   *          - should be true if the game is over, false otherwise
   */
  public synchronized void setGameOver(boolean gameOver) {
    this.gameOver = gameOver;
  }

  /**
   * Indicates if a new ship should be created/drawn.
   * 
   * @return if a new ship should be created/drawn
   */
  public synchronized boolean isNewShip() {
    return newShip;
  }

  /**
   * Sets the status of the player's ship.
   * 
   * @param newShip
   *          - should be true if the player's ship is new, false otherwise
   */
  public synchronized void setNewShip(boolean newShip) {
    this.newShip = newShip;
  }

  /**
   * 
   * @return the number of asteroid destroyed
   */
  public synchronized long getAsteroidsDestroyed() {
    return asteroidsDestroyed;
  }

  /**
   * 
   * @return the number of enemy ships destroyed
   */
  public synchronized long getEnemyShipsDestroyed() {
    return enemyShipsDestroyed;
  }

  /**
   * 
   * @return the number of targets destroyed
   */
  public synchronized long getTargetsDestroyed() {
    return asteroidsDestroyed + enemyShipsDestroyed;
  }

 
  /**
   * Sets the enemy ships destroyed.
   * 
   * @param enemyShipsDestroyed
   *          - the number of enemy ships that have been destroyed
   */
  public synchronized void setEnemyShipsDestroyed(long enemyShipsDestroyed) {
    long newEnemyShipsDestroyed = enemyShipsDestroyed - this.enemyShipsDestroyed;
    this.enemyShipsDestroyed = enemyShipsDestroyed;
    setPoints(getPoints() + Rules.ENEMY_SHIP_POINTS * newEnemyShipsDestroyed);
  }

  /**
   * Set the asteroids destroyed
   * 
   * 
   * @param asteroidsDestroyed
   *          
   */
  public synchronized void setAsteroidsDestroyed(long asteroidsDestroyed) {
    long newDestroyedAsteroids = asteroidsDestroyed - this.asteroidsDestroyed;
    this.asteroidsDestroyed = asteroidsDestroyed;
    setPoints(getPoints() + Rules.ASTEROID_POINTS * newDestroyedAsteroids);
  }

  

  /**
   * Returns the number ships/lives left.
   * 
   * @return the number ships left
   */
  public synchronized int getShipsLeft() {
    return shipsLeft;
  }

  /**
   * Sets the number of the player's ships left.
   * 
   * @param shipsLeft
   *          - the number of the player's ships left
   */
  public synchronized void setShipsLeft(int shipsLeft) {
    this.shipsLeft = shipsLeft;
  }

  /*
   * 
   * @return the number of points the player has
   */
  public synchronized long getPoints() {
    return points;
  }

  /**
   * 
   * @param points the number of points the player has
   *          
   */
  public synchronized void setPoints(long points) {
    this.points = points;
    updateLevel();
  }

  /**
   * 
   * @return the level the player is in
   */
  public synchronized int getLevel() {
    return this.level;
  }



  /**
   * The number of ship the player has left depend on the level
   * @param level
   *         
   */
  public synchronized void playerShipsLeft(int level) {
    if (!gameStarting && level != 1 && level % Rules.LEVELS_UP_PLAYERSHIPS == 0)
      this.shipsLeft += Rules.INCREASE_PLAYERSHIP_PER_LEVELS;
  }

  /**
   * Asteroids present in the screen depend on the level
   * 
   * @param level
   *          
   */
  public synchronized void asteroidCounter(int level) {
    // To change the asteroid count in a different level
    ArrayList<Asteroid> asteroids = gameLogic.getAsteroidList();
    if (level == Rules.LEVEL2_ASTEROIDS
        && asteroids.size() < Rules.ASTEROIDS2) {
      // Specific number of asteroids
      int asteroidsToAdd = Rules.ASTEROIDS2 - asteroids.size();
      for (int i = 0; i < asteroidsToAdd; i++)
        asteroids.add(gameLogic.newAsteroid(gameLogic.getGameScreen()));
    } else if (level == Rules.LEVEL3_ASTEROIDS
        && asteroids.size() < Rules.ASTEROIDS3) {
      int asteroidsToAdd = Rules.ASTEROIDS3 - asteroids.size();
      for (int i = 0; i < asteroidsToAdd; i++)
        asteroids.add(gameLogic.newAsteroid(gameLogic.getGameScreen()));
    }
  }

  /**
   * Enemy Ships presented in the screen depends on the level
   * 
   * @param level
   *        
   */
  public synchronized void enemyShipCounter(int level) {
    // Change the enemy Ship in a different level
    ArrayList<EnemyShip> enemyShips = gameLogic.getEnemyShipList();
    if (level == Rules.LEVEL_UP_ENEMYSHIPS2
        && enemyShips.size() < Rules.ENEMYSHIPS2) {
      // Specific number of enemy Ships 
      int enemyShipsToAdd = Rules.ENEMYSHIPS2 - enemyShips.size();
      for (int i = 0; i < enemyShipsToAdd; i++)
        enemyShips.add(gameLogic.newEnemyShip(gameLogic.getGameScreen()));
    } else if (level == Rules.LEVEL_UP_ENEMYSHIPS3 
        && enemyShips.size() < Rules.ENEMYSHIPS3) {
      int enemyShipsToAdd = Rules.ENEMYSHIPS3 - enemyShips.size();
      for (int i = 0; i < enemyShipsToAdd; i++)
        enemyShips.add(gameLogic.newEnemyShip(gameLogic.getGameScreen()));
    }
  }
  
  /**
   * Game Logic
   * 
   * @param gameLogic
   *         
   */
  public synchronized void gameLogicSet(GameLogic gameLogic) {
    this.gameLogic = gameLogic;
  }

  /**
   * Sets the level for the player
   * 
   * 
   * @param level
   *        
   */
  public synchronized void setLevel(int level) {
    // Change of the Level change
    if (level != this.level) {
      playerShipsLeft(level);
      asteroidCounter(level);
      enemyShipCounter(level);
      this.level = level;
    }
  }

  /**
   * Change the level if the player complete the points or the targets
   */
  public synchronized void updateLevel() {
    if (Rules.CHANGING_LEVEL)
      setLevel((int) (getPoints() / Rules.POINTS_FOR_LEVEL_UP + 1));
    else
      setLevel((int) (getEnemyShipsDestroyed() + getAsteroidsDestroyed())
          / Rules.TARGETS_FOR_LEVEL_UP + 1);
  }

 

}
