package rbadia.voidspace.sounds;

import java.applet.Applet;
import java.applet.AudioClip;

import rbadia.voidspace.main.GameScreen;

/**
 * Manages and plays the game's sounds.
 */
public class SoundManager {
  private static final boolean SOUND_ON = true;

  private AudioClip shipExplosionSound = Applet.newAudioClip(GameScreen.class
      .getResource("/rbadia/voidspace/sounds/shipExplosion.wav"));
  private AudioClip bulletSound = Applet.newAudioClip(GameScreen.class
      .getResource("/rbadia/voidspace/sounds/laser.wav"));
  private AudioClip enemyShipExplosionSound = Applet.newAudioClip(GameScreen.class
	      .getResource("/rbadia/voidspace/sounds/enemyShipExplosion.wav"));
  private AudioClip inmortalSound = Applet.newAudioClip(GameScreen.class
	      .getResource("/rbadia/voidspace/sounds/Inmortal.wav"));
  private AudioClip enemyLaserSound = Applet.newAudioClip(GameScreen.class
	      .getResource("/rbadia/voidspace/sounds/enemyLaser.wav"));
  private AudioClip GameOverSound = Applet.newAudioClip(GameScreen.class
	      .getResource("/rbadia/voidspace/sounds/GameOver.wav"));
  private AudioClip newGameSound = Applet.newAudioClip(GameScreen.class
	      .getResource("/rbadia/voidspace/sounds/haveyou.wav"));
 
 
 

  /**
   * Plays sound for bullets fired by the ship.
   */
  public void playBulletSound() {
    if (SOUND_ON) {
      new Thread(new Runnable() {
        public void run() {
          bulletSound.play();
        }
      }).start();
    }
  }

  /**
   * Plays sound for bullets fired by the enemy ships.
   */
  public void playEnemyBulletSound() {
    if (SOUND_ON) {
    	{
    	      new Thread(new Runnable() {
    	        public void run() {
    	          enemyLaserSound.play();
    	        }
    	      }).start();

    	}}
  }

  /**
   * Plays sound for ship explosions.
   */
  public void playShipExplosionSound() {
    if (SOUND_ON) {
      new Thread(new Runnable() {
        public void run() {
          shipExplosionSound.play();
        }
      }).start();
    }
  }



  /**
   * Plays sound for asteroid explosions.
   */
  public void playAsteroidExplosionSound() {
       if (SOUND_ON)  new Thread(new Runnable() {
        public void run() {
            shipExplosionSound.play();
          }
        }).start();
  }

  /**
   * Plays sound for the explosions of the enemy ships.
   */
  public void playEnemyShipExplosionSound() {
        if (SOUND_ON)  new Thread(new Runnable() {
        public void run() {
            enemyShipExplosionSound.play();
          }
        }).start();
  }

  /**
   * Plays sound for inmortal.
   */
public void playInmortal() {
	if (SOUND_ON)  new Thread(new Runnable() {
        public void run() {
            inmortalSound.play();
          }
        }).start();
	
}

public void playNewGame(){
	if (SOUND_ON)  new Thread(new Runnable() {
        public void run() {
            newGameSound.play();
          }
        }).start();
	
}

public void playGameOver() {
		GameOverSound.play();
	
}
}
