package rbadia.voidspace.model;

import rbadia.voidspace.main.GameScreen;

public class Inmortal extends Asteroid {   
  private int inmortalWidth = 48;
  private int inmortalHeight = 48;
  private int inmortalSpeed = 2;
  
  /**
   * To construct the inmortal
   * @param screen
   */

 public Inmortal(GameScreen screen) {
		super(screen);
			
    super.setSize(inmortalWidth, inmortalHeight);
    super.setSpeed(inmortalSpeed);
  }

  private static final long serialVersionUID = 1L;


}