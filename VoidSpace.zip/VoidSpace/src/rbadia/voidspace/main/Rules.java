package rbadia.voidspace.main;

/**
 * Final Variables for the Game Rules to configured the game.
 *
 */
public class Rules {


	public static final int STARTING_SHIPS = 5;
	public static final int ENEMY_SHIP_POINTS = 1000;
	public static final int ASTEROID_POINTS = 500;
	// Delays // Size // Level UP
	public static final int MAINX_FRAME = 800;
	public static final int MAINY_FRAME = 600;
	public static final int GAMEX_FRAME = 700;
	public static final int GAMEY_FRAME = 500;
	public static final int SHIP_DELAY = 500;
	public static final int ASTEROID_DELAY = 500;
	public static final int ENEMY_SHIP_DELAY = 500;
	public static final boolean CHANGING_LEVEL = false;
	public static final int POINTS_FOR_LEVEL_UP = 1000;
	public static final int TARGETS_FOR_LEVEL_UP = 10;
	public static final int GET_READY_DELAY_TIME = 1500;
	public static final int GAME_OVER_DELAY_TIME = 3000;
	// asteroid changes
	public static final boolean ASTEROID_TRASLATION = false;
	public static final boolean ASTEROID_MOVEMENT = false;
	public static final int LEVEL_UP_ASTEROIDS = 3;
	public static final int LEVEL_UP_ASTEROIDS2 = 6;
	public static final int LEVEL_UP_ASTEROIDS3 = 10;
	public static final double ACCELERATE_ASTEROIDS2 = 1.4;
	public static final double ACCELERATE_ASTEROIDS3 = 1.8;
	public static final int LEVEL2_ASTEROIDS = 2;
	public static final int LEVEL3_ASTEROIDS = 10;
	public static final int ASTEROIDS1 = 1;
	public static final int ASTEROIDS2 = 4;
	public static final int ASTEROIDS3 = 6;
	//Enemy Ships
	public static final int LEVEL_UP_ENEMYSHIPS2 = 5;
	public static final int LEVEL_UP_ENEMYSHIPS3 = 10;
	public static final int ENEMYSHIPS1 = 1;
	public static final int ENEMYSHIPS2 = 3;
	public static final int ENEMYSHIPS3 = 5;
	public static final int LEVEL_TO_MOVE_ENEMY_SHIP_2X = 5;
	public static final int LEVEL_TO_MOVE_ENEMY_SHIP_3X = 10;
	public static final double ACCELERATE_ENEMYSHIP2 = 1.4;
	public static final double ACCELERATE_ENEMYSHIP3 = 1.8;
	//Player
	public static final int LEVEL_UP_BULLETS = 5;
	public static final int BULLETS_PER_SECOND = 5;
	public static final int ACCELERATE_BULLETS_PER_SECOND = 7;
	public static final int LEVELS_UP_PLAYERSHIPS = 1;
	public static final int INCREASE_PLAYERSHIP_PER_LEVELS = 1;
	// Inmortal
	public static final int NUM_INMORTALS = 1;

}
